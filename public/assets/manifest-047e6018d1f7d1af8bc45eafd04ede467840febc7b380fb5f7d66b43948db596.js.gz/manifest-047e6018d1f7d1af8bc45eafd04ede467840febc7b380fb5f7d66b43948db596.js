

// app/assets/config/manifest.js

;
